import { createApp } from "vue";
import App from "./App.vue";
import router from "./router";
import store from "./store";

import BaseCard from "./components/UI/BaseCard.vue";
import BaseButton from "@/components/UI/BaseButton.vue";

import "@popperjs/core/dist/umd/popper.min.js";
import "bootstrap/dist/css/bootstrap.css";
import "bootstrap/dist/js/bootstrap.js";

import "./global.css";

const app = createApp(App);

app.component("base-card", BaseCard);
app.component("base-button", BaseButton);
app.use(store);
app.use(router);
app.mount("#app");
