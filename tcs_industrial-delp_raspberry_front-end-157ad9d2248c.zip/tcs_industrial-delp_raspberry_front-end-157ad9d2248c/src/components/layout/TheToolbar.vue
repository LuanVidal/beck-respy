<template>
  <div class="toolbar">
    <div class="row">
      <div class="col-3">
        <img class="logoIcon" src="@/assets/images/Logo.png" alt="">
      </div>
      <div class="col-6">
        <b>{{ currentTime }}</b>
      </div>
      <div class="col-3">
        <div class="row">
          <div class="col-8">
            <b>{{ dayOfTheWeekExt }}</b>
          </div>
          <div class="col-4">
            <img class="wifi" src="@/assets/images/wifi-white.png" alt="">
            <img v-if="!online" class="wifilost" src="@/assets/images/fail_red_wifi.png" alt="">
          </div>
        </div>


      </div>
    </div>
  </div>
</template>

<script>
import { defineComponent } from "vue";

export default defineComponent({
  name: "Toolbar1",
  data() {
    return {
      online: false,
      currentTime: null,
      dayOfTheWeek: null,
      weekday: ["Domingo", "Segunda-feira", "Terça-feira", "Quarta-feira", "Quinta-feira", "Sexta-feira", "Sábado"],
    }
  },
  methods: {
    getTime() {
      this.currentTime = new Date().toLocaleTimeString();
      this.dayOfTheWeek = new Date().getDay();
    },
    checkOnline() {
      if (navigator.onLine) {
        this.online = true;
      } else {
        this.online = false;
      }
    }
  },
  computed: {
    dayOfTheWeekExt() {
      return this.weekday[this.dayOfTheWeek]
    }

  },
  created() {
    this.getTime();
    this.checkOnline();
    setInterval(() => {
      this.getTime();
      this.checkOnline();
    }, 1000);
  }
});
</script>

<style scoped>
.logoIcon {
  width: 4.5rem;
}

b {
  letter-spacing: -0.05em;
}

.toolbar {
  position: relative;
  text-align: center;
  height: 57px;
  background-image: url("@/assets/images/toolbar.png");
  background-size: cover;
  background-repeat: no-repeat;
  background-position: top;
  font-size: var(--font-size-base);
  color: var(--color-white);
  font-family: var(--font-roboto);
  padding: 0.75rem;
}

.wifi {
  width: 48px;
}

.row {
  align-items: baseline;
}

.wifilost {
  position: absolute;
  width: 17px;
  top: 24px;
  right: 32px;
}
</style>
