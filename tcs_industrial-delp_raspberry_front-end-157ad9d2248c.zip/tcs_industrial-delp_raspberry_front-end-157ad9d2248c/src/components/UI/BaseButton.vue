<template>
  <div>
    <slot></slot>
  </div>
</template>

<style scoped>
div {
  position: relative;
  border-radius: 12px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.26);
  /* border: 1px solid #360032; */
  padding: 0.5rem;
  margin: 0;
  padding: 0.35rem;
}

.buttondefault {
  position: relative;
  padding-top: 123px;
  border-radius: var(--br-3xs);
  /* background-color: var(--color-gray); */
  width: 315px;
  height: 103px;
  text-align: center;
  font-size: var(--font-size-xl);
  color: var(--color-white);
  font-family: var(--font-roboto-condensed);
}
</style>