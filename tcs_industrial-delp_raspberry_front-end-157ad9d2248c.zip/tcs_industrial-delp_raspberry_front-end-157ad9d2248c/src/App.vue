<template>
    <the-toolbar></the-toolbar>
    <router-view v-slot="{ Component }">
        <transition name="fade" mode="out-in">
            <component :is="Component"></component>
        </transition>
    </router-view>
    <img class="fundoIcon" src="@/assets/images/fundo.png" />
</template>

<script>
import Swal from 'sweetalert2'
import { socket } from './socket'
import TheToolbar from './components/layout/TheToolbar.vue';

export default {
    name: 'App',
    methods: {
        displayAlert() {
            socket.on('swal', (data) => {
                Swal.fire({
                    title: data.title,
                    text: data.text,
                    icon: data.type || "error",
                    timer: data.time || 2500,
                    showConfirmButton: false,
                });
            });
        },
        changePage() {
            socket.on('changepath', (pageName) => {
                this.$router.push({ name: pageName, params: {} });
            });
        }
    },
    mounted() {
        this.displayAlert();
        this.changePage();
    },
    components: { TheToolbar }
}
</script>

<style>
.fade-enter-active,
.fade-leave-active {
    transition: opacity 0.15s;
}

.fade-enter,
.fade-leave-to {
    opacity: 0;
}

.fundoIcon {
    position: absolute;
    top: 0px;
    left: 0px;
    width: 100%;
    height: 100%;
    z-index: -1;
    /* object-fit: cover; */
}

h1 {
    text-align: center;
    font-size: var(--font-size-xl);
    color: var(--color-white);
    font-family: var(--font-roboto-condensed);
}

h2 {
    text-align: center;
    font-size: var(--font-size-xl);
    color: var(--color-white);
    font-family: var(--font-roboto-condensed);
}
</style>