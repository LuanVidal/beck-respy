import { createRouter, createWebHistory } from "vue-router";

import loginService from "@/services/login";
import { perms } from "@/helpers/auth";

import ConfigMatricula from "../views/ConfigMatricula.vue";
import Rastreabilidade from "../views/ShowRastreabilidade.vue";
import Home from "../views/Home.vue";
import ConfigOrdemProducao from "../views/ConfigOrdemProducao.vue";
import ConfigID from "../views/ConfigID.vue";
import ConfigConsumivel from "../views/ConfigConsumivel";
import FinalizaProcesso from "@/views/FinalizaProcesso";
import ValidaRequest from "@/views/ValidaRequest";
import RetomaProcesso from "@/views/RetomaProcesso.vue";

const routes = [
  {
    path: "/",
    name: "home",
    component: Home,
    meta: {
      title: "Tela Inicial",
      perms: perms(),
      ativo: true,
    },
  },
  {
    path: "/rastreabilidade",
    name: "rastreabilidade",
    component: Rastreabilidade,
    meta: {
      title: "Rastreabilidade",
      perms: perms(),
      ativo: true,
    },
  },
  {
    path: "/matricula",
    name: "matricula",
    component: ConfigMatricula,
    meta: {
      title: "Matricula",
      perms: perms(),
      ativo: true,
    },
  },
  {
    path: "/ordemproducao",
    name: "ordemproducao",
    component: ConfigOrdemProducao,
    meta: {
      title: "Ordem Producao",
      perms: perms(),
      ativo: true,
    },
  },
  {
    path: "/id",
    name: "id",
    component: ConfigID,
    meta: {
      title: "ID",
      perms: perms(),
      ativo: true,
    },
  },
  {
    path: "/consumivel",
    name: "consumivel",
    component: ConfigConsumivel,
    meta: {
      title: "Consumivel",
      perms: perms(),
      ativo: true,
    },
  },
  {
    path: "/finaliza",
    name: "finaliza",
    component: FinalizaProcesso,
    meta: {
      title: "Finaliza Processo",
      perms: perms(),
      ativo: true,
    },
  },
  {
    path: "/validando",
    name: "validando",
    component: ValidaRequest,
    meta: {
      title: "Finaliza Processo",
      perms: perms(),
      ativo: true,
    },
  },
  {
    path: "/retoma",
    name: "retoma",
    component: RetomaProcesso,
    meta: {
      title: "Retoma Processo",
      perms: perms(),
      ativo: true,
    },
  },
];

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes,
});

router.beforeEach((to, from, next) => {
  next();
  return;
  if (!to.meta.perms) next(); // página pública
  else if (!to.meta.ativo) next({ name: "404" }); // página pública
  else if (!loginService.isLoggedIn()) next({ name: "login" }); // não logado
  else if (!loginService.verifyPermissions(to.meta.perms))
    next({ name: "403" }); // sem permissão
  else next(); // acesso permitido
});

export default router;
