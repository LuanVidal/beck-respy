import { createStore } from "vuex";

export default createStore({
  state: {
    matricula: "",
    ordemDeProducao: "",
    id: "",
    consumivel: "",
    elapsedTime: 0,
    elapsedPausedTime: 0,
    stopwatchInterval: 0,
    startTime: 0,
    firstStartTime: 0,
    iniciado: false,
  },
  getters: {
    matricula(state) {
      return state.matricula;
    },
    ordemDeProducao(state) {
      return state.ordemDeProducao;
    },
    consumivel(state) {
      return state.consumivel;
    },
    id(state) {
      return state.id;
    },
  },
  mutations: {
    addMatricula(state, newValue) {
      state.matricula = newValue;
    },
    addOrdemProducao(state, newValue) {
      state.ordemDeProducao = newValue;
    },
    addId(state, newValue) {
      state.id = newValue;
    },
    addConsumivel(state, newValue) {
      state.consumivel = newValue;
    },
    setElapsedTime(state, newValue) {
      state.elapsedTime = newValue;
    },
    setElapsedPausedTime(state, newValue) {
      state.elapsedPausedTime = newValue;
    },
    setStopwatchInterval(state, newValue) {
      state.stopwatchInterval = newValue;
    },
    setStartTime(state, newValue) {
      state.startTime = newValue;
    },
    setIniciado(state, newValue) {
      state.iniciado = newValue;
    },
    setFirstStartTime(state, newValue) {
      state.firstStartTime = newValue;
    },
  },
  actions: {},
  modules: {},
});
