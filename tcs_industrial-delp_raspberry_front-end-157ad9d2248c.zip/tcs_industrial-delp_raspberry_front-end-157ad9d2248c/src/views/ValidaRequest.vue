<template>
    <div class="container">
        <div class="row">
            <div class="col-6">
                <base-card class="message">
                    <div class="row">
                        <div class="spinner-border text-light spin-custom"></div>
                        <img src="@/assets/images/AGUARDE.svg" alt="">
                    </div>
                    <div class="row">
                        <h1>AGUARDE</h1>
                    </div>

                    <div class="row">
                        <h2>VALIDANDO DADOS <br>
                            NO SERVIDOR </h2>
                    </div>
                </base-card>
            </div>
        </div>
    </div>
</template>

<script>

export default {
}
</script>

<style scoped>
h2 {
    text-align: center;
    font-size: large;
    color: var(--color-white);
    font-family: var(--font-roboto-condensed);
}

h1 {
    text-align: center;
    font-size: x-large;
    color: var(--color-white);
    font-family: var(--font-roboto-condensed);
}

p {
    font-size: xx-large;
    color: var(--color-white);
    font-family: var(--font-roboto-condensed);
    letter-spacing: 0.75rem;
    padding: 0.1rem;
    margin: 0.25rem;
}

img {
    padding: 1rem;
    max-height: 120px;
    margin: 0.2rem;
}

.row {
    justify-content: center;
}

.container {
    justify-content: center;
    height: 420px;
    display: flex;
    flex-direction: column
}

.message {
    height: 330px;
    align-items: center;
}

.spin-custom {
    position: absolute;
    top: 145.9px;
    left: 364.9px;
    width: 70px;
    height: 70px;
}
</style>