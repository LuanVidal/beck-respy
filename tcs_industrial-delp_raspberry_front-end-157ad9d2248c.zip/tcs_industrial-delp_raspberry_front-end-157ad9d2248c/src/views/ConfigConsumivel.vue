<template>
  <div class="container">
    <div class="row">
      <div class="col-5">

        <div class="row">
          <base-card class="card-adjust">
            <div class="row">
              <h1>CONFIGURAÇÃO INICIAL</h1>
            </div>

            <div class="row">
              <img src="@/assets/images/icontool.svg" alt="">
            </div>

            <div class="row">
              <h2>IDENTIFICAÇÃO DA ORDEM <br>
                INSIRA O CONSUMÍVEL </h2>
            </div>
            <div class="row align-items-center">
              <div class="formamatriculaItem align-items-center">
                <p>{{ consumivel }}</p>
              </div>
            </div>
          </base-card>
        </div>
        <div class="row">

          <section class="col">
            <base-button>
              <h4>CONFIRMA<br>
                TECLE #</h4>
            </base-button>
          </section>
          <section class="col">
            <base-button>
              <h4>CORRIGE <br>
                TECLE D</h4>
            </base-button>
          </section>
          <section class="col">
            <base-button>
              <h4>ANTERIOR<br>
                TECLE * </h4>
            </base-button>
          </section>
        </div>
      </div>
      <div class="col-7">
        <base-card>
          <h1>CONSUMÍVEL</h1>
          <h4>CONSULTA</h4>
          <section>
            <b>01 - 01.053.0128798 [ ARAME SOLD MIG 1,2mm MET SCXCP 18kg AWS A 5.18 / A
              5.18 M 2005 ER 70 S ]</b> <br>
          </section>
          <section>
            <b>02 - 01.053.0129082 [ ARAME GMAW AWS A5.14 ERNICRMO-3 Ø1,14 MM ]</b> <br>
          </section>

          <section>
            <b>03 - 01.053.0129766 [ ARAME FCAW AWS A5.20 E71T-1CJ Ø 1,2 MM BOB. 16 KG
              ESAB DUAL SHIELD 71 ]</b> <br>
          </section>

          <section>
            <b>04 - 01.053.0129771 [ ARAME FCAW AWS A5.20 E71T-1C Ø 1,6 MM BOB. 16 KG
              ESAB TUBROD 71 ULTRA FBTS-DNV ]</b> <br>
          </section>

          <section>
            <b>05 - 01.053.0129772 [ ARAME FCAW AWS A5.20 E71T-1C Ø 1,2 MM BOB. 16 KG
              ESAB TUBROD 71 ULTRA FBTS-DNV]</b> <br>
          </section>

          <section>
            <b>06 - 01.053.0141585 [ ARAME FCAW AWS A5.20 E71T-1C Ø 1,2 MM BOB. 16 KG
              ESAB TUBROD 71 ULTRA FBTS-DNV ABS - MBF ]</b> <br>
          </section>



        </base-card>
      </div>
    </div>
  </div>
</template>

<script>

import { socket } from "@/socket";

export default {
  name: "Consumivel",
  data() {
    return {
      consumivel: '',
    }
  },
  methods: {
    listenConsumivel() {
      socket.on('consumivel', (arg) => {
        arg = arg.padStart(2, '0');
        this.consumivel = arg;
        this.$store.commit('addConsumivel', this.consumivel);
      })
    },
  },
  mounted() {
    this.listenConsumivel()
  }
};
</script>
<style scoped>
b {
  text-align: center;
  font-size: 13.5px;
  color: var(--color-white);
  font-family: var(--font-roboto-condensed);
}

h4 {
  text-align: center;
  font-size: 16px;
  color: var(--color-white);
  font-family: var(--font-roboto-condensed);
}

h3 {
  text-align: center;
  font-size: medium;
  color: var(--color-white);
  font-family: var(--font-roboto-condensed);
  padding: 4px;
}

h2 {
  text-align: center;
  font-size: large;
  color: var(--color-white);
  font-family: var(--font-roboto-condensed);
}

h1 {
  text-align: center;
  font-size: x-large;
  color: var(--color-white);
  font-family: var(--font-roboto-condensed);
}

img {
  padding: 0.1rem;
  max-height: 50px;
  margin: 0.7rem;
}

.formamatriculaItem {
  border-radius: var(--br-7xs);
  background-color: var(--color-gainsboro);
  height: 50px;
  width: fit-content;
  margin: 1rem;
  text-align: center;
  vertical-align: middle;
  min-width: 70px;

}

.row {
  justify-content: center;
  width: auto;
}

.col {
  justify-content: center;
  width: auto;
}

.container {
  /* justify-content: center; */
  height: 420px;
  /* display: flex;
  flex-direction: column */
}

section {
  padding: 0.17rem;
}

.card-adjust {
  height: 280px;
}

p {
  font-size: xx-large;
  color: var(--color-white);
  font-family: var(--font-roboto-condensed);
  padding: 0.1rem;
  margin: 0.25rem;
  letter-spacing: 0.5em;
  margin-right: -0.4em;
}
</style>