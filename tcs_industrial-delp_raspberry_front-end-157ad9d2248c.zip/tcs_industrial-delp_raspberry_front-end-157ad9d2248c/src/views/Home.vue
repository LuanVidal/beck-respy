<template>
  <div>
    <img class="home" src="@/assets/images/home@3x.png" alt="">
    <img class="logoIcon" src="@/assets/images/Logo.png" />
    <div class="technologiesCreative">
      Technologies & Creative Solutions
    </div>
  </div>
</template>
  
<script>
export default {
  name: "Home",
};
</script>

<style scoped>
.logoIcon {
  position: absolute;
  top: 162.5px;
  left: 263.5px;
  width: 272px;
  height: 122px;
  object-fit: cover;
}

.technologiesCreative {
  position: absolute;
  top: 297.5px;
  left: 277.5px;
  letter-spacing: -0.05em;
  color: white;
  text-align: center;
  font-size: var(--font-size-base);
  font-family: var(--font-montserrat);
}

.home {
  position: absolute;
  top: 0;
  height: 480px;
  background-size: cover;
  background-repeat: no-repeat;
  background-position: top;
}
</style>
  