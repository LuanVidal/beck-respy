<template>
  <div class="container">
    <div class="row">
      <div class="col">
        <base-card class="card-adjust">
          <div class="row">
            <h1>CONFIGURAÇÃO INICIAL</h1>
          </div>

          <div class="row">
            <img src="@/assets/images/ordemProd.svg" alt="">
          </div>

          <div class="row">
            <h2>IDENTIFICAÇÃO DA ORDEM <br>
              INSIRA ORDEM DE PRODUÇÃO </h2>
          </div>

          <div class="row align-items-center">
            <div class="formamatriculaItem align-items-center">
              <p>{{ OrdemProd }}</p>
            </div>
          </div>

        </base-card>
      </div>
      <div class="col">
        <base-card>
          <h1>CONFIRMA</h1>
          <h2>TECLE #</h2>
        </base-card>
        <base-card>
          <h1>CORRIGE</h1>
          <h2>TECLE D</h2>
        </base-card>
        <base-card>
          <h1>ANTERIOR</h1>
          <h2>TECLE *</h2>
        </base-card>
      </div>
    </div>
  </div>
</template>

<script>
import { socket } from "@/socket";

export default {
  name: "ConfigOrdemProducao",
  data() {
    return {
      OrdemProd: ''
    }
  },
  methods: {
    listenOrdemProducao() {
      socket.on('ordemProducao', (arg) => {
        this.OrdemProd = arg
        this.$store.commit('addOrdemProducao', this.OrdemProd)
      })
    },
  },
  mounted() {
    this.listenOrdemProducao()
  }

};
</script>

<style scoped>
h2 {
  text-align: center;
  font-size: large;
  color: var(--color-white);
  font-family: var(--font-roboto-condensed);
}

h1 {
  text-align: center;
  font-size: x-large;
  color: var(--color-white);
  font-family: var(--font-roboto-condensed);
}

p {
  font-size: xx-large;
  color: var(--color-white);
  font-family: var(--font-roboto-condensed);
  padding: 0.1rem;
  margin: 0.25rem;
  letter-spacing: 0.5em;
  margin-right: -0.4em;
}

img {
  padding: 1rem;
  max-height: 120px;
  margin: 0.2rem;
}

.formamatriculaItem {
  border-radius: var(--br-7xs);
  background-color: var(--color-gainsboro);
  height: 50px;
  width: fit-content;
  margin: 1rem;
  text-align: center;
  vertical-align: middle;
  min-width: 100px;
}

.row {
  justify-content: center;
}

.container {
  justify-content: center;
  height: 420px;
  display: flex;
  flex-direction: column
}

.card-adjust {
  height: 329px;
}
</style>
