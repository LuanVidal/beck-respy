<template>
    <div class="container">
        <div class="row">
            <div class="col-3">
                <base-card>
                    <h2>MATRÍCULA</h2>
                    <h2>{{ parameters.matricula }}</h2>
                </base-card>
                <base-card>
                    <h2>ORDEM DE PROD</h2>
                    <h2>{{ parameters.ordemProd }}</h2>
                </base-card>
                <base-card>
                    <h2>ID</h2>
                    <h2>{{ parameters.id }}</h2>
                </base-card>
                <base-card>
                    <h2>CONSUMÍVEL</h2>
                    <h2>{{ parameters.consumivel }}</h2>
                </base-card>
            </div>
            <div class="col-9">

                <base-card>

                    <div class="row">
                        <img src="@/assets/images/MENSAGEM.svg" alt="">
                    </div>
                    <h1>MENSAGEM</h1>
                    <h4>DESEJA RETOMAR O PROCESSO ANTERIOR?</h4>
                    <!-- <h2>DADOS:</h2> -->
                </base-card>

                <div class="row">
                    <div class="col">
                        <base-card class="retomar">
                            <h1>RETOMAR</h1>
                            <h2>TECLE #</h2>
                        </base-card>
                    </div>
                    <div class="col">
                        <base-card>
                            <h1>NOVO</h1>
                            <h2>TECLE *</h2>
                        </base-card>
                    </div>
                </div>

            </div>

        </div>
    </div>
</template>

<script>

import { socket } from "@/socket";

function pad(number) {
    // add a leading zero if the number is less than 10
    return (number < 10 ? "0" : "") + number;
}

export default {
    name: "Retoma",
    data() {
        return {
            parameters: {
                // matricula: '',
                // ordemProd: '',
                // id: '',
                // consumivel: '',
            },
        }
    },
    methods: {
        listenParameters() {
            socket.on('retoma-params', (arg) => {
                this.parameters = arg;
                this.$store.commit('addMatricula', this.parameters.matricula)
                this.$store.commit('addOrdemProducao', this.parameters.ordemProd)
                this.$store.commit('addId', this.parameters.id)
                this.$store.commit('addConsumivel', this.parameters.consumivel)
            })
        },
        initializeParameters() {
            this.$store.commit('setStartTime', null)
        }
    },
    mounted() {
        this.listenParameters();
    }
};
</script>

<style scoped>
h4 {
    text-align: center;
    font-size: large;
    color: var(--color-white);
    font-family: var(--font-roboto-condensed);
    padding: 0rem;
    margin: 0.1rem;
}

h3 {
    text-align: justify;
    font-size: large;
    color: var(--color-white);
    font-family: var(--font-roboto-condensed);
    padding: 0rem;
    margin: 0.1rem;
}

h2 {
    text-align: center;
    font-size: 17px;
    color: var(--color-white);
    font-family: var(--font-roboto-condensed);
    padding: 0rem;
    margin: 0.1rem;
}

h1 {
    text-align: center;
    font-size: x-large;
    color: var(--color-white);
    font-family: var(--font-roboto-condensed);
    padding: 0.5rem;
}

p {
    font-size: xx-large;
    color: var(--color-white);
    font-family: var(--font-roboto-condensed);
    letter-spacing: 0.75rem;
    padding: 0.1rem;
    margin: 0.25rem;
}

img {
    max-height: 90px;
    margin: 0.2rem;
}

.row {
    justify-content: center;
}

.container {
    justify-content: center;
    height: 420px;
    display: flex;
    flex-direction: column
}

section {
    margin-top: 10px;
    padding: 0.5rem;
    border-radius: 6px;
}

.retomar {
    background-color: darkolivegreen;
}
</style>