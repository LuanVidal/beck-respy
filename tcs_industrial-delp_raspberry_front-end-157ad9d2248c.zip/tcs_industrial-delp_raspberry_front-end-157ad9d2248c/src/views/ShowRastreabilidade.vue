<template>
  <div class="container">
    <div class="row">
      <div class="col-3">
        <base-card>
          <h2>MATRÍCULA</h2>
          <h2>{{ numeromatricula }}</h2>
        </base-card>
        <base-card>
          <h2>ORDEM DE PROD</h2>
          <h2>{{ numeroOrdemProducao }}</h2>
        </base-card>
        <base-card>
          <h2>ID</h2>
          <h2>{{ numeroId }}</h2>
        </base-card>
        <base-card>
          <h2>CONSUMÍVEL</h2>
          <h2>{{ numeroConsumivel }}</h2>
        </base-card>
      </div>
      <div class="col-6">
        <base-card>
          <h1>RASTREABILIDADE</h1>
          <section>
            <h3>TENSÃO {{ parameters.Tensao }}V</h3>
          </section>
          <section>
            <h3>CORRENTE {{ parameters.Corrente }}A</h3>
          </section>
          <section>
            <h3>INÍCIO {{ tempoInicial.hours }}:{{ tempoInicial.minutes }}:{{ tempoInicial.seconds }}</h3>
          </section>
          <section>
            <h3>PERCORRIDO {{ tempoPercorridoPad.hours }}:{{ tempoPercorridoPad.minutes }}:{{
              tempoPercorridoPad.seconds }} </h3>
          </section>
        </base-card>
      </div>
      <div class="col-3">
        <base-card>
          <h1 v-if="iniciado">PAUSA</h1>
          <h1 v-else>REINICIA</h1>
          <h2>TECLE #</h2>
        </base-card>
        <base-card :class="{ 'disable-finaliza': !iniciado }">
          <h1>FINALIZA</h1>
          <h2>TECLE *</h2>
        </base-card>
      </div>
    </div>
  </div>
</template>

<script>

import { socket } from "@/socket";

function pad(number) {
  // add a leading zero if the number is less than 10
  return (number < 10 ? "0" : "") + number;
}

export default {
  name: "Frame",
  data() {
    return {
      parameters: {
        Corrente: '',
        Tensao: '',
      },
      iniciado: false,
      startTime: 0,
      firstStartTime: 0,
      stopwatchInterval: 0,
      elapsedPausedTime: 0,
      elapsedTime: 0,
      tempoPercorrido: {
        seconds: 0,
        minutes: 0,
        hours: 0,
      }
    }
  },
  methods: {
    initializeValues() {
      this.startTime = this.$store.state.startTime;
      this.elapsedPausedTime = this.$store.state.elapsedPausedTime;
      this.iniciado = this.$store.state.iniciado;
      this.firstStartTime = this.$store.state.firstStartTime;
    },
    listenParameters() {
      if (this.iniciado) {
        socket.on('parameters', (arg) => {
          this.parameters.Corrente = arg.Corrente;
          this.parameters.Tensao = arg.Tensao;
        })
      }

    },
    listenAction() {
      socket.on('rastreabilidade', (arg) => {
        if (arg === 'inicia') {
          this.startStopwatch();
        } else if (arg === 'pausa') {
          this.stopStopwatch();
        }
      })
    },
    startStopwatch() {
      if (!this.stopwatchInterval) {
        if (!this.iniciado) {
          console.log("Iniciando startTime");
          this.startTime = new Date().getTime() - this.elapsedPausedTime; // get the starting time by subtracting the elapsed paused time from the current time
          this.$store.commit('setStartTime', this.startTime);
        }
        if (!this.firstStartTime) {
          this.firstStartTime = this.startTime;
          this.$store.commit('setFirstStartTime', this.firstStartTime)
        }
        this.stopwatchInterval = setInterval(this.updateStopwatch, 1000); // update every second
        this.iniciado = true;
        this.$store.commit('setIniciado', this.iniciado)
      }
    },

    stopStopwatch() {
      clearInterval(this.stopwatchInterval); // stop the interval
      this.elapsedPausedTime = new Date().getTime() - this.startTime; // calculate elapsed paused time
      this.stopwatchInterval = null; // reset the interval variable
      this.iniciado = false;
      this.$store.commit('setIniciado', this.iniciado)
      this.$store.commit('setElapsedPausedTime', this.elapsedPausedTime)
    },

    resetStopwatch() {
      stopStopwatch(); // stop the interval
      this.elapsedPausedTime = 0; // reset the elapsed paused time variable
    },
    updateStopwatch() {
      const currentTime = new Date().getTime(); // get current time in milliseconds
      this.elapsedTime = currentTime - this.startTime; // calculate elapsed time in milliseconds
      this.tempoPercorrido.seconds = Math.floor(this.elapsedTime / 1000) % 60; // calculate seconds
      this.tempoPercorrido.minutes = Math.floor(this.elapsedTime / 1000 / 60) % 60; // calculate minutes
      this.tempoPercorrido.hours = Math.floor(this.elapsedTime / 1000 / 60 / 60); // calculate hours
    },
    sendData() {
      socket.emit('dadosTempo', {
        tempoInicial: this.tempoInicial,
        tempoPercorrido: this.tempoPercorrido
      })
    }
  },
  computed: {
    numeromatricula() {
      console.log(this.$store.getters.matricula);
      return this.$store.getters.matricula
    },
    numeroOrdemProducao() {
      console.log(this.$store.getters.ordemDeProducao);
      return this.$store.getters.ordemDeProducao
    },
    numeroId() {
      console.log(this.$store.getters.id);
      return this.$store.getters.id
    },
    numeroConsumivel() {
      console.log(this.$store.getters.consumivel);
      return this.$store.getters.consumivel
    },
    tempoInicial() {
      const tempoInicial = {}
      const startTime = this.firstStartTime;
      tempoInicial.seconds = Math.floor(startTime / 1000) % 60; // calculate seconds
      tempoInicial.minutes = Math.floor(startTime / 1000 / 60) % 60; // calculate minutes
      tempoInicial.hours = Math.floor(startTime / 1000 / 60 / 60) % 24 + 1; // calculate hours
      return tempoInicial
    },
    tempoPercorridoPad() {
      return {
        seconds: pad(this.tempoPercorrido.seconds),
        minutes: pad(this.tempoPercorrido.minutes),
        hours: pad(this.tempoPercorrido.hours),
      }
    },
  },
  beforeMount() {
    this.initializeValues();
  },
  mounted() {
    this.startStopwatch();
    this.listenParameters();
    this.listenAction();
    this.sendData();
  }
};
</script>

<style scoped>
h3 {
  text-align: justify;
  font-size: large;
  color: var(--color-white);
  font-family: var(--font-roboto-condensed);
  padding: 0rem;
  margin: 0.1rem;
}

h2 {
  text-align: center;
  font-size: large;
  /* color: var(--color-white); */
  font-family: var(--font-roboto-condensed);
  padding: 0rem;
  margin: 0.1rem;
}

h1 {
  text-align: center;
  font-size: x-large;
  /* color: var(--color-white); */
  font-family: var(--font-roboto-condensed);
}

p {
  font-size: xx-large;
  color: var(--color-white);
  font-family: var(--font-roboto-condensed);
  letter-spacing: 0.75rem;
  padding: 0.1rem;
  margin: 0.25rem;
}

img {
  padding: 1rem;
  max-height: 120px;
  margin: 0.2rem;
}

.row {
  justify-content: center;
}

.container {
  justify-content: center;
  height: 420px;
  display: flex;
  flex-direction: column;
  color: var(--color-white);
}

div {
  padding: 0.3rem;
}

section {
  border: 0.1px solid rgba(255, 255, 255, 0.25);
  margin-top: 10px;
  padding: 0.5rem;
  border-radius: 6px;
  text-align: justify;
  /* display: table-row; */
  text-align-last: justify;
}

.disable-finaliza {
  color: rgba(255, 255, 255, 0.236);
}
</style>