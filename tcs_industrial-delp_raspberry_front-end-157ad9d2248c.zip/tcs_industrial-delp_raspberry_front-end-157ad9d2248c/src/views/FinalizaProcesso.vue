<template>
  <div class="container">
    <div class="row">
      <div class="col-7">
        <base-card class="message">
          <div class="row">
            <img src="@/assets/images/MENSAGEM.svg" alt="">
          </div>
          <div class="row">
            <h1>MENSAGEM</h1>
          </div>

          <div class="row">
            <h2>CERTEZA QUE DESEJA <br>
              FINALIZAR O PROCESSO?</h2>
          </div>

        </base-card>
      </div>
      <div class="col-5">
        <base-card>
          <h1>CONFIRMA</h1>
          <h2>TECLE #</h2>
        </base-card>
        <base-card>
          <h1>ANTERIOR</h1>
          <h2>TECLE *</h2>
        </base-card>
      </div>
    </div>
  </div>
</template>

<script>

export default {
  name: "FinalizaProcesso",
};
</script>
<style scoped>
h2 {
  text-align: center;
  font-size: large;
  color: var(--color-white);
  font-family: var(--font-roboto-condensed);
}

h1 {
  text-align: center;
  font-size: x-large;
  color: var(--color-white);
  font-family: var(--font-roboto-condensed);
}

p {
  font-size: xx-large;
  color: var(--color-white);
  font-family: var(--font-roboto-condensed);
  letter-spacing: 0.75rem;
  padding: 0.1rem;
  margin: 0.25rem;
}

img {
  padding: 1rem;
  max-height: 120px;
  margin: 0.2rem;
}

.formamatriculaItem {
  border-radius: var(--br-7xs);
  background-color: var(--color-gainsboro);
  height: 50px;
  width: fit-content;
  margin: 1rem;
  text-align: center;
  vertical-align: middle;

}

.row {
  justify-content: center;
}

.container {
  justify-content: center;
  height: 420px;
  display: flex;
  flex-direction: column
}

.message {
  height: 330px;
  align-items: center;
  background-color: #c0392b;
}
</style>
