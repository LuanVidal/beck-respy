<template>
  <div class="container">
    <div class="row">
      <div class="col-5">
        <base-card class="card-adjust">
          <div class="row">
            <h1>CONFIGURAÇÃO INICIAL</h1>
          </div>

          <div class="row">
            <img src="@/assets/images/ID.svg" alt="">
          </div>

          <div class="row">
            <h2>IDENTIFICAÇÃO DA ORDEM <br>
              INSIRA ID </h2>
          </div>

          <div class="row align-items-center">
            <div class="formamatriculaItem align-items-center">
              <p>{{ id }}</p>
            </div>
          </div>

        </base-card>
      </div>
      <div class="col-3">
        <base-card>
          <h1>CONFIRMA</h1>
          <h2>TECLE #</h2>
        </base-card>
        <base-card>
          <h1>CORRIGE</h1>
          <h2>TECLE D</h2>
        </base-card>
        <base-card>
          <h1>ANTERIOR</h1>
          <h2>TECLE *</h2>
        </base-card>
      </div>
      <div class="col-4">
        <div class="row">
          <base-card>
            <h1>ID</h1>
            <h3>Consulta</h3>
            <section class="item">
              01 | Maquina 1
            </section>
            <section class="item">
              02 | Maquina 2
            </section>
            <section class="item">
              03 | Maquina 3
            </section>
            <section class="item">
              04 | Maquina 4
            </section>
            <section class="item">
              05 | Maquina 5
            </section>
            <section class="item">
              06 | Maquina 6
            </section>
            <section class="item">
              07 | Maquina 7
            </section>
          </base-card>
        </div>
        <div class="row">
          <div class="col">
            <base-button>
              <h3>ANT A</h3>
            </base-button>
          </div>
          <div class="col">
            <base-button>
              <h3>PROX B</h3>
            </base-button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>

import { socket } from "@/socket";

export default {
  name: "ConfigMatricula",
  data() {
    return {
      id: ''
    }
  },

  methods: {
    listenId() {
      socket.on('idNumber', (arg) => {
        console.log(arg);
        arg = arg.padStart(2, '0');
        this.id = arg
        this.$store.commit('addId', this.id)
      })
    },
  },
  mounted() {
    this.listenId()
  }
};
</script>

<style scoped>
h3 {
  text-align: center;
  font-size: small;
  color: var(--color-white);
  font-family: var(--font-roboto-condensed);
}

h2 {
  text-align: center;
  font-size: large;
  color: var(--color-white);
  font-family: var(--font-roboto-condensed);
}

h1 {
  text-align: center;
  font-size: x-large;
  color: var(--color-white);
  font-family: var(--font-roboto-condensed);
}

p {
  font-size: xx-large;
  color: var(--color-white);
  font-family: var(--font-roboto-condensed);
  padding: 0.1rem;
  margin: 0.25rem;
  letter-spacing: 0.5em;
  margin-right: -0.4em;
}

img {
  padding: 1rem;
  max-height: 120px;
  margin: 0.2rem;
}

.formamatriculaItem {
  border-radius: var(--br-7xs);
  background-color: var(--color-gainsboro);
  height: 50px;
  width: fit-content;
  margin: 1rem;
  text-align: center;
  vertical-align: middle;
  min-width: 70px;
}

.row {
  justify-content: center;
}

.container {
  justify-content: center;
  height: 420px;
  display: flex;
  flex-direction: column
}

section {
  text-align: center;
  font-size: small;
  color: var(--color-white);
  font-family: var(--font-roboto-condensed);
  margin-top: 3px;
}

.item {
  border: 0.1px solid rgba(255, 255, 255, 0.25);
  border-radius: 12px;
  border-width: 1px;
  padding: 0.2rem;
}

.card-adjust {
  height: 329px;
}
</style>
